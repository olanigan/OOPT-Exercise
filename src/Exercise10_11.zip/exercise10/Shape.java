
package exercise10;

/**
 *
 * @author Ibrahim Olanigan
 */
public interface Shape {
    
    public abstract void draw();
}
