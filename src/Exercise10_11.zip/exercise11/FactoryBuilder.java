
package exercise11;

/**
 *
 * @author Ibrahim Olanigan
 */
public abstract class FactoryBuilder {
    
    public abstract Dog CreateDog(String number);
}
