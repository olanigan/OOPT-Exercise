
package exercise11;

/**
 *
 * @author Ibrahim Olanigan
 */
public interface Dog {
    
    public abstract void bark();
}
