
package exercise11;

/**
 *
 * @author Ibrahim Olanigan
 */
public class Breed3 implements Dog {
    
    public Breed3(){
        System.out.println("Breed 3 dog created");
    }
    
    @Override
    public void bark() {
     System.out.println("Breed 3 dog barking");
       }
    
}
